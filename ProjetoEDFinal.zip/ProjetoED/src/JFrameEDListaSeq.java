import javax.swing.JOptionPane;
import estruturas.*;
//import listas.*;

/**
 *
 * @author Hercules
 */
public class JFrameEDListaSeq extends javax.swing.JInternalFrame {

    public JFrameEDListaSeq() {
        initComponents();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        opposicao = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        mensagem = new javax.swing.JFormattedTextField();
        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        opadicionar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        opremover = new javax.swing.JButton();
        list1 = new java.awt.List();
        opelemento = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setPreferredSize(new java.awt.Dimension(600, 400));

        opposicao.setText("Consultar posicao");
        opposicao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opposicaoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel4.setText("Lista Sequencial");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        mensagem.setEditable(false);
        mensagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mensagemActionPerformed(evt);
            }
        });

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel1.setText("Elemento:");

        opadicionar.setText("Adicionar");
        opadicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opadicionarActionPerformed(evt);
            }
        });

        jLabel2.setText("Posição:");

        opremover.setText("Remover");
        opremover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opremoverActionPerformed(evt);
            }
        });

        list1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        list1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                list1ItemStateChanged(evt);
            }
        });
        list1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list1ActionPerformed(evt);
            }
        });

        opelemento.setText("Consultar elemento");
        opelemento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opelementoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(47, 47, 47)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(55, 55, 55)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(opadicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(opremover, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(opelemento, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(opposicao, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addComponent(list1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(mensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel1))
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel2))
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addComponent(opadicionar)
                        .addGap(6, 6, 6)
                        .addComponent(opremover)
                        .addGap(6, 6, 6)
                        .addComponent(opelemento)
                        .addGap(6, 6, 6)
                        .addComponent(opposicao))
                    .addComponent(list1, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(mensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void opposicaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opposicaoActionPerformed
        int dado,pos;
        pos = Integer.parseInt(jTextField2.getText());
        dado = lista.elemento(pos);
        if (dado == -1) {
            mensagem.setText("Posição Inválida.");
            jTextField1.setText("");
            jTextField2.setText("");
        } else {
            mensagem.setText("A posição " + pos
                    + " contém o elemento " + dado + ".");
        }
        jTextField1.setText("");
        jTextField2.setText("");
    }//GEN-LAST:event_opposicaoActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void mensagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mensagemActionPerformed
        
    }//GEN-LAST:event_mensagemActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void opadicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opadicionarActionPerformed
        jTextField1.setEditable(true);
        jTextField1.setEnabled(true);
        jTextField2.setEditable(true);
        jTextField2.setEnabled(true);
        int dado = Integer.parseInt(jTextField1.getText());
        int pos = Integer.parseInt(jTextField2.getText());
            
            if (!lista.insere(pos, dado)) {
                mensagem.setText("A lista está cheia ou a posição é invalida.");
                jTextField1.setText("");
                jTextField2.setText("");
            } else {
                list1.add(String.valueOf(dado), pos - 1);
                mensagem.setText("Elemento adicionado");
                jTextField1.setText("");
                jTextField2.setText("");
            }
    }//GEN-LAST:event_opadicionarActionPerformed

    private void opremoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opremoverActionPerformed
        int pos = Integer.parseInt(jTextField2.getText());
        int dado = lista.remove(pos);
        list1.remove(pos - 1);

        if (dado == -1) {
            mensagem.setText("Elemento nao encontrado");
            jTextField1.setText("");
            jTextField2.setText("");
        } else {
            mensagem.setText("Elemento removido");
        }
        jTextField1.setText("");
        jTextField2.setText("");
    }//GEN-LAST:event_opremoverActionPerformed

    private void list1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_list1ItemStateChanged
      
    }//GEN-LAST:event_list1ItemStateChanged

    private void list1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list1ActionPerformed
       
    }//GEN-LAST:event_list1ActionPerformed

    private void opelementoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opelementoActionPerformed
        int dado = Integer.parseInt(jTextField1.getText());
        int pos = lista.posicao(dado);

        if (pos == -1) {
            mensagem.setText("Elemento nao encontrado");
            jTextField1.setText("");
            jTextField2.setText("");
        } else {
            mensagem.setText("Elemento " + dado + " está na posição " + pos);
        }
        jTextField1.setText("");
        jTextField2.setText("");
    }//GEN-LAST:event_opelementoActionPerformed
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrameEDListaSeq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFrameEDListaSeq().setVisible(true);
                
            }
        });
    }
    private ListaSeq lista = new ListaSeq(Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho: ")));
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private java.awt.List list1;
    private javax.swing.JFormattedTextField mensagem;
    private javax.swing.JButton opadicionar;
    private javax.swing.JButton opelemento;
    private javax.swing.JButton opposicao;
    private javax.swing.JButton opremover;
    // End of variables declaration//GEN-END:variables

}
