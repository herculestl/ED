
/**
 *
 * @author Hercules
 */

import estruturas.*;
//import listas.*;

public class JFrameEDListaSE extends javax.swing.JInternalFrame {

    public JFrameEDListaSE() {
        initComponents();
    }
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new JFrameEDListaSE().setVisible(true);
        });
    }
    private LSE lista = new LSE();
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        mensagem = new javax.swing.JFormattedTextField();
        list1 = new java.awt.List();
        jLabel4 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Lista Simplesmente Encadeada");
        setPreferredSize(new java.awt.Dimension(600, 400));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Adicionar", "Consultar Elemento", "Consultar Posição", "Remover" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel1.setText("Elemento:");

        jLabel2.setText("Posição:");

        mensagem.setEditable(false);

        list1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        list1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                list1ItemStateChanged(evt);
            }
        });
        list1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list1ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel4.setText("Lista Simplesmente Encadeada");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(64, 64, 64))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jTextField1)
                                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(list1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(mensagem)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(list1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(39, 39, 39)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1)))
                .addGap(8, 8, 8)
                .addComponent(mensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        switch (jComboBox1.getSelectedIndex()) {
            case 0:
            jTextField1.setEditable(true);
            jTextField1.setEnabled(true);
            jTextField2.setEditable(true);
            jTextField2.setEnabled(true);
            break;
            case 1:
            jTextField1.setEditable(true);
            jTextField1.setEnabled(true);
            jTextField2.setEditable(false);
            jTextField2.setEnabled(true);
            break;
            case 2:
            jTextField1.setEditable(false);
            jTextField1.setEnabled(true);
            jTextField2.setEditable(true);
            jTextField2.setEnabled(true);
            break;
            case 3:
            jTextField1.setEditable(false);
            jTextField1.setEnabled(false);
            jTextField2.setEditable(true);
            jTextField2.setEnabled(true);
            break;

        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int dado,pos;
        switch (jComboBox1.getSelectedIndex()) {
            case 0:
            dado = Integer.parseInt(jTextField1.getText());
            pos = Integer.parseInt(jTextField2.getText());

            if (!lista.insere(pos, dado)) {
                try{
                }catch (NullPointerException e) {
                    mensagem.setText("A lista está cheia ou"
                        + " a posição é invalida.");
                }
                jTextField1.setText("");
                jTextField2.setText("");
            } else {
                list1.add(String.valueOf(dado), pos - 1);
                mensagem.setText("Elemento adicionado.");
            }

            jTextField1.setText("");
            jTextField2.setText("");

            break;

            case 1:
            dado = Integer.parseInt(jTextField1.getText());

            pos = lista.posicao(dado);

            if (pos == -1) {
                mensagem.setText("Elemento não encontrado.");
                jTextField1.setText("");
                jTextField2.setText("");
            } else {
                mensagem.setText("Elemento " + dado + " está na posição "
                    + pos + ".");
                jTextField1.setText("");
                jTextField2.setText("");
            }
            break;

            case 2:
            pos = Integer.parseInt(jTextField2.getText());
            dado = lista.elemento(pos);
            if (dado == -1) {
                mensagem.setText("Posição Inválida.");
                jTextField1.setText("");
                jTextField2.setText("");

            } else {
                mensagem.setText("A posição " + pos + " contém o elemento " + dado + ".");
            }
            jTextField1.setText("");
            jTextField2.setText("");
            break;
            case 3:
            pos = Integer.parseInt(jTextField2.getText());
            dado = lista.remove(pos);
            list1.remove(pos - 1);
            if (dado == -1) {
                mensagem.setText("Elemento não encontrado.");
                jTextField1.setText("");
                jTextField2.setText("");
            } else {
                mensagem.setText("Elemento removido");
            }
            jTextField1.setText("");
            jTextField2.setText("");
            break;
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void list1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_list1ItemStateChanged
        
    }//GEN-LAST:event_list1ItemStateChanged

    private void list1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list1ActionPerformed
        
    }//GEN-LAST:event_list1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private java.awt.List list1;
    private javax.swing.JFormattedTextField mensagem;
    // End of variables declaration//GEN-END:variables
}
